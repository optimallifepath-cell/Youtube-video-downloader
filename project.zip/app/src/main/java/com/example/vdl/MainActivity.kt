package com.example.vdl

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.*
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var urlInput: EditText
    private lateinit var quality: Spinner
    private lateinit var btn: Button
    private lateinit var updBtn: Button
    private lateinit var bar: ProgressBar
    private lateinit var status: TextView
    private val ex = Executors.newSingleThreadExecutor()
    @Volatile private var ready = false

    private val labels = listOf("1080p", "720p", "480p", "শুধু অডিও")
    private val formats = listOf(
        "bv*[height<=1080][vcodec^=avc1]+ba[ext=m4a]/bv*[height<=1080]+ba/b[height<=1080]/b",
        "bv*[height<=720][vcodec^=avc1]+ba[ext=m4a]/bv*[height<=720]+ba/b[height<=720]/b",
        "bv*[height<=480][vcodec^=avc1]+ba[ext=m4a]/bv*[height<=480]+ba/b[height<=480]/b",
        "ba[ext=m4a]/ba/b"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val title = TextView(this).apply { text = "Video DL"; textSize = 24f }
        urlInput = EditText(this).apply { hint = "ভিডিও/রিল লিংক পেস্ট করুন"; setSingleLine(false) }
        quality = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, labels)
        }
        btn = Button(this).apply { text = "ডাউনলোড"; setOnClickListener { startDownload() } }
        updBtn = Button(this).apply { text = "yt-dlp আপডেট"; setOnClickListener { updateEngine() } }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        status = TextView(this).apply { text = "ইঞ্জিন চালু হচ্ছে..."; gravity = Gravity.START }
        val sv = ScrollView(this).apply { addView(status) }
        for (v in listOf(title, urlInput, quality, btn, bar, updBtn)) {
            root.addView(v, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        root.addView(sv, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)

        handleIntent(intent)

        ex.execute {
            try {
                YoutubeDL.getInstance().init(application)
                FFmpeg.getInstance().init(application)
                ready = true
                ui("প্রস্তুত। লিংক দিয়ে ডাউনলোড চাপুন।")
            } catch (e: Throwable) {
                ui("ইঞ্জিন চালু করতে সমস্যা: ${e.message}")
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            i.getStringExtra(Intent.EXTRA_TEXT)?.let { urlInput.setText(it.trim()) }
        }
    }

    private fun ui(msg: String) = runOnUiThread { status.text = msg }

    private fun extractUrl(text: String): String =
        Regex("https?://\\S+").find(text)?.value ?: text.trim()

    private fun updateEngine() {
        if (!ready) { ui("ইঞ্জিন এখনো প্রস্তুত নয়"); return }
        ui("আপডেট হচ্ছে...")
        ex.execute {
            try {
                val r = YoutubeDL.getInstance().updateYoutubeDL(application, YoutubeDL.UpdateChannel.STABLE)
                ui("আপডেট ফলাফল: $r")
            } catch (e: Throwable) {
                ui("আপডেট ব্যর্থ: ${e.message}")
            }
        }
    }

    private fun startDownload() {
        if (!ready) { ui("ইঞ্জিন এখনো প্রস্তুত নয়, একটু অপেক্ষা করুন"); return }
        val url = extractUrl(urlInput.text.toString())
        if (!url.startsWith("http")) { ui("সঠিক লিংক দিন"); return }
        val idx = quality.selectedItemPosition
        val audioOnly = idx == 3
        btn.isEnabled = false
        bar.progress = 0
        ui("শুরু হচ্ছে...")

        ex.execute {
            try {
                val dir = File(getExternalFilesDir(null), "dl").apply {
                    mkdirs(); listFiles()?.forEach { it.delete() }
                }
                val req = YoutubeDLRequest(url)
                req.addOption("--no-playlist")
                req.addOption("-f", formats[idx])
                if (!audioOnly) req.addOption("--merge-output-format", "mp4")
                req.addOption("-o", dir.absolutePath + "/%(title).80s.%(ext)s")

                YoutubeDL.getInstance().execute(req, "dl") { p, _, line ->
                    runOnUiThread {
                        if (p >= 0) bar.progress = p.toInt()
                        status.text = line
                    }
                }

                val files = dir.listFiles()?.filter {
                    !it.name.endsWith(".part") && !it.name.endsWith(".ytdl")
                } ?: emptyList()
                if (files.isEmpty()) { ui("ফাইল পাওয়া যায়নি"); return@execute }
                files.forEach { saveToDownloads(it) }
                ui("সম্পন্ন! Downloads/VideoDL ফোল্ডারে আছে:\n" + files.joinToString("\n") { it.name })
            } catch (e: Throwable) {
                ui("ব্যর্থ: ${e.message}")
            } finally {
                runOnUiThread { btn.isEnabled = true }
            }
        }
    }

    private fun saveToDownloads(f: File) {
        val ext = f.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, f.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VideoDL")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("সেভ করা যায়নি")
        contentResolver.openOutputStream(uri)!!.use { out ->
            f.inputStream().use { it.copyTo(out) }
        }
        f.delete()
    }
}
